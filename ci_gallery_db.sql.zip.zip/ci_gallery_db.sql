-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 08, 2018 at 08:04 PM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 7.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ci_gallery_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_user`
--

CREATE TABLE `admin_user` (
  `id` int(11) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `username` varchar(100) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `full_name` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_user`
--

INSERT INTO `admin_user` (`id`, `email`, `username`, `password`, `full_name`) VALUES
(1, 'jawadabbass@hotmail.com', 'jawadabbas', '$2y$10$iRIjJQk2WIJ8k.FSpD6toO60jIaOjlnr3nBofZdTN5KCkVl87ILNS', 'Muhammad Jawad Abbas');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `category` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `category`) VALUES
(1, 'Animals'),
(5, 'Landscape'),
(6, 'Cars'),
(7, 'Aircrafts');

-- --------------------------------------------------------

--
-- Table structure for table `gallery`
--

CREATE TABLE `gallery` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `category_id` int(11) NOT NULL DEFAULT '0',
  `description` varchar(250) DEFAULT NULL,
  `image_name` varchar(250) DEFAULT NULL,
  `title` varchar(100) DEFAULT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `gallery`
--

INSERT INTO `gallery` (`id`, `user_id`, `category_id`, `description`, `image_name`, `title`, `status`) VALUES
(16, 12, 7, 'The Sukhoi Su-24 (NATO reporting name: Fencer) is a supersonic, all-weather attack aircraft developed in the Soviet Union. The aircraft has a variable-sweep wing, twin-engines and a side-by-side seating arrangement for its two crew. It was the first ', 'su-24-.jpg', 'SU-24', 'active'),
(17, 12, 7, 'The Sukhoi Su-24 (NATO reporting name: Fencer) is a supersonic, all-weather attack aircraft developed in the Soviet Union. The aircraft has a variable-sweep wing, twin-engines and a side-by-side seating arrangement for its two crew. It was the first ', 'su-24-1.jpg', 'SU-24', 'active'),
(18, 12, 7, 'The Sukhoi Su-35 (Russian: ????? ??-35; NATO reporting name: Flanker-E) is the designation for two improved derivatives of the Su-27 air-defence fighter. They are single-seat, twin-engine, highly-maneuverable aircraft, designed by the Sukhoi Design B', 'su-35-.jpg', 'SU-35', 'active'),
(19, 12, 7, 'The Sukhoi Su-35 (Russian: ????? ??-35; NATO reporting name: Flanker-E) is the designation for two improved derivatives of the Su-27 air-defence fighter. They are single-seat, twin-engine, highly-maneuverable aircraft, designed by the Sukhoi Design B', 'su-35-1.jpg', 'SU-35', 'active'),
(20, 12, 7, 'The Sukhoi Su-34 (NATO reporting name: Fullback) is a Russian twin-engine, twin-seat, all-weather supersonic medium-range fighter-bomber/strike aircraft. It first flew in 1990 and entered service in 2014 with the Russian ', 'sukhoi-su-34-.jpg', 'Sukhoi Su-34', 'active'),
(21, 12, 7, 'The Sukhoi Su-34 (NATO reporting name: Fullback) is a Russian twin-engine, twin-seat, all-weather supersonic medium-range fighter-bomber/strike aircraft. It first flew in 1990 and entered service in 2014 with the Russian', 'sukhoi-su-34-1.jpg', 'Sukhoi Su-34', 'active'),
(22, 12, 7, 'The Sukhoi Su-34 (NATO reporting name: Fullback) is a Russian twin-engine, twin-seat, all-weather supersonic medium-range fighter-bomber/strike aircraft. It first flew in 1990 and entered service in 2014 with the Russian', 'sukhoi-su-34-2.jpg', 'Sukhoi Su-34', 'active'),
(23, 12, 1, 'The koala (Phascolarctos cinereus, or, inaccurately, koala bear[a]) is an arboreal herbivorous marsupial native to Australia. It is the only extant representative of the family Phascolarctidae and its closest living relatives are the wombats. The koa', 'koala-.jpg', 'Koala', 'active'),
(24, 12, 1, 'Penguins (order Sphenisciformes, family Spheniscidae) are a group of aquatic, flightless birds. They live almost exclusively in the Southern Hemisphere, with only one species, the Galapagos penguin, found north of the equator. Highly adapted for life', 'penguins-.jpg', 'Penguins', 'active'),
(25, 12, 1, 'Jellyfish or jellies[1] are softbodied, free-swimming aquatic animals with a gelatinous umbrella-shaped bell and trailing tentacles. The bell can pulsate to acquire propulsion and locomotion. The tentacles may be utilized to capture prey or defend ag', 'jellyfish-.jpg', 'Jellyfish', 'active'),
(26, 12, 5, 'A lighthouse is a tower, building, or other type of structure designed to emit light from a system of lamps and lenses and to serve as a navigational aid for maritime pilots at sea or on inland waterways.', 'lighthouse-.jpg', 'Lighthouse', 'active'),
(27, 12, 5, 'A desert is a barren area of landscape where little precipitation occurs and consequently living conditions are hostile for plant and animal life. The lack of vegetation exposes the unprotected surface of the ground to the processes of denudation. Ab', 'desert-.jpg', 'Desert', 'active'),
(28, 12, 5, 'A desert is a barren area of landscape where little precipitation occurs and consequently living conditions are hostile for plant and animal life. The lack of vegetation exposes the unprotected surface of the ground to the processes of denudation. Ab', 'desert-1.JPG', 'Desert', 'active'),
(29, 12, 6, 'A car (or automobile) is a wheeled motor vehicle used for transportation. Most definitions of car say they run primarily on roads, seat one to eight people, have four tires, and mainly transport people rather than goods.[2][3] Cars came into global u', 'car-.jpg', 'Car', 'active'),
(30, 12, 6, 'A car (or automobile) is a wheeled motor vehicle used for transportation. Most definitions of car say they run primarily on roads, seat one to eight people, have four tires, and mainly transport people rather than goods.[2][3] Cars came into global u', 'car-1.jpg', 'Car', 'active'),
(31, 12, 6, 'A car (or automobile) is a wheeled motor vehicle used for transportation. Most definitions of car say they run primarily on roads, seat one to eight people, have four tires, and mainly transport people rather than goods.[2][3] Cars came into global u', 'car-2.jpg', 'Car', 'active'),
(32, 13, 5, 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.', 'what-is-lorem-ipsum-.jpg', 'What is Lorem Ipsum', 'active'),
(33, 13, 5, 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.', 'what-is-lorem-ipsum-1.jpg', 'What is Lorem Ipsum', 'active'),
(34, 13, 5, 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.', 'what-is-lorem-ipsum-2.jpg', 'What is Lorem Ipsum', 'active'),
(35, 13, 5, 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.', 'what-is-lorem-ipsum-3.jpg', 'What is Lorem Ipsum', 'active'),
(36, 13, 6, 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.', 'what-is-lorem-ipsum-4.jpg', 'What is Lorem Ipsum', 'active'),
(37, 13, 6, 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.', 'what-is-lorem-ipsum-5.jpg', 'What is Lorem Ipsum', 'active'),
(38, 14, 7, 'The Sukhoi Su-25 Grach is a single-seat, twin-engine jet aircraft developed in the Soviet Union by Sukhoi. It was designed to provide close air support for the Soviet Ground Forces. The first prototype made its maiden flight on 22 February 1975', 'sukhoi-su-25-.jpg', 'Sukhoi Su-25', 'active'),
(39, 14, 7, 'The Sukhoi Su-25 Grach is a single-seat, twin-engine jet aircraft developed in the Soviet Union by Sukhoi. It was designed to provide close air support for the Soviet Ground Forces. The first prototype made its maiden flight on 22 February 1975', 'sukhoi-su-25-1.jpg', 'Sukhoi Su-25', 'active'),
(40, 14, 7, 'The Mil Mi-24 (Russian: ???? ??-24; NATO reporting name: Hind) is a large helicopter gunship, attack helicopter and low-capacity troop transport with room for eight passengers.[1] It is produced by Mil Moscow Helicopter Plant and has been operated si', 'mil-mi-24-.jpg', 'Mil Mi-24', 'active'),
(41, 14, 7, 'The Mil Mi-24 (Russian: ???? ??-24; NATO reporting name: Hind) is a large helicopter gunship, attack helicopter and low-capacity troop transport with room for eight passengers.[1]', 'mil-mi-24-1.jpg', 'Mil Mi-24', 'active'),
(42, 14, 1, 'The sheep is a quadrupedal, ruminant mammal typically kept as livestock. Like all ruminants, sheep are members of the order Artiodactyla, the even-toed ungulates', 'sheep-.jpg', 'Sheep', 'active'),
(43, 14, 1, 'Owls are birds from the order Strigiformes, which includes about 200 species of mostly solitary and nocturnal birds of prey typified by an upright stance, a large, broad head, binocular vision, binaural ', 'owl-.jpg', 'Owl', 'active'),
(44, 14, 1, 'The koala is an arboreal herbivorous marsupial native to Australia. It is the only extant representative of the family Phascolarctidae and its closest living relatives are the wombats. The koala is found in coastal areas of the mainland\'s eastern and', 'koala-1.jpg', 'Koala', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `site_users`
--

CREATE TABLE `site_users` (
  `id` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `image` varchar(100) DEFAULT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `site_users`
--

INSERT INTO `site_users` (`id`, `email`, `password`, `full_name`, `image`, `status`) VALUES
(12, 'jawadabbass@hotmail.com', '$2y$10$iRIjJQk2WIJ8k.FSpD6toO60jIaOjlnr3nBofZdTN5KCkVl87ILNS', 'Muhammad Jawad Abbas', 'jawad-abbas-.jpg', 'active'),
(13, 'fakhir.ali@hotmail.com', '$2y$10$v1Xnt3cgkPiOwx8zbvFJKukH8ViZwIfKyPx2gJsmQiLK3kO3k26QO', 'Fakhir Ali', 'fakhir-ali-1.jpg', 'active'),
(14, 'kumail@hotmail.com', '$2y$10$.ZDFObC60wdPFya/xJJz8.aMw6lHGN3QNHc5QZbEAzL1NyrWP/JL6', 'Muhammad Kumail', 'muhammad-kumail-.jpg', 'active');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_user`
--
ALTER TABLE `admin_user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `gallery`
--
ALTER TABLE `gallery`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `site_users`
--
ALTER TABLE `site_users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_user`
--
ALTER TABLE `admin_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `gallery`
--
ALTER TABLE `gallery`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;
--
-- AUTO_INCREMENT for table `site_users`
--
ALTER TABLE `site_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
